from flask import Flask, render_template, request

app = Flask(__name__)

CORRECT_ANSWERS = {'name': 'admin', 'password': 'admin'}

@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")

@app.route("/class", methods=["POST"])
def class_selection():
    name = request.form.get("name")
    password = request.form.get("password")

    if name == CORRECT_ANSWERS['name'] and password == CORRECT_ANSWERS['password']:
        return render_template("results.html")
    else:
        return render_template("results_fall.html")

if __name__ == "__main__":
    app.run(debug=True)

#     return render_template("questions.html", name=name, user_class=user_class)
#
# @app.route("/results", methods=["POST"])
# def results():
#     name = request.form.get("name")
#     user_class = request.form.get("class")
#     question1 = int(request.form.get("question1"))
#     question2 = int(request.form.get("question2"))